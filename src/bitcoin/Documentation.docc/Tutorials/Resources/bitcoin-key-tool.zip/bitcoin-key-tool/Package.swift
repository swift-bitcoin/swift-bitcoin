// swift-tools-version: 6.2
import PackageDescription

let package = Package(
    name: "BitcoinKeyTool",
    platforms: [.macOS(.v26)],
    dependencies: [
        .package(url: "https://github.com/apple/swift-argument-parser.git", from: "1.7.0"),
        .package(path: "../swift-bitcoin")
    ],
    targets: [
        .executableTarget(
            name: "keytool",
            dependencies: [
                .product(name: "ArgumentParser", package: "swift-argument-parser"),
                .product(name: "Bitcoin", package: "swift-bitcoin")
            ]        )
    ]
)
