import ArgumentParser
import Bitcoin

struct GenerateSecretKey: ParsableCommand {

    func run() {
        let key = SecretKey()
        print("Secret key: \(key)")
    }
}
