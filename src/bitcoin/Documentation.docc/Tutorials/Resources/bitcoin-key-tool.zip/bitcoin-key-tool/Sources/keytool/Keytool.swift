import ArgumentParser

@main
struct Keytool: ParsableCommand {

    static let configuration = CommandConfiguration(
        subcommands: [
            GenerateSecretKey.self,
            DerivePublicKey.self,
            SignMessage.self,
            VerifySignature.self,
            HashMessage.self,
            SignMessageHash.self,

            HashPublicKey.self,
            RecoverableSignMessage.self,
            VerifyRecoverableSignature.self,

            SchnorrSignMessage.self,
            TweakPublicKey.self,
            VerifySchnorrSignature.self
        ]
    )
}
